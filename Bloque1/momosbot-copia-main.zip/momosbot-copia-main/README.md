# python -m venv {nombre del entorno}
CMD: .\env\Scripts\activate
## pip install pillow tweepy
# UML
![77b1db2f-b9bc-4970-bf83-6c0dca8a655a](https://github.com/user-attachments/assets/6f8787d3-cd47-422a-babe-6978d36b84f8)
